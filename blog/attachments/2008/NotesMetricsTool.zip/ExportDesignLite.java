import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.DxlExporter;
import lotus.domino.NoteCollection;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

import org.w3c.dom.DocumentFragment;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * Exports the design from a given database
 * 
 * @author stw
 * 
 */
public class ExportDesignLite extends NotesThread {

	/**
	 * Delay timer to prevent crashes in the exporter
	 */
	private long crashPreventSleepTime = 88;

	/**
	 * Directory for exporting to
	 */
	private String basePath;

	/**
	 * Name of the NSF to be exported
	 */
	private String nsfToExport;

	/**
	 * Name of the server, default is local (empty)
	 */
	private String server = "";

	/**
	 * Master object if there is any. This master object is only used when
	 * ExportDesignLite is used with ExportAllDesigns for a given server
	 */
	private ExportAllDesigns ead = null;

	/**
	 * The Notes session
	 * 
	 */
	private Session s = null;

	/**
	 * List of databases we worked on. To avoid a loop only used together with
	 * ExportAllDesigns
	 */
	private HashMap<String, Boolean> databasesWorkedOn = new HashMap<String, Boolean>();

	/**
	 * @param args
	 *            1) Output directory 2) Name of the database 3) Name of the
	 *            server
	 */
	public static void main(String[] args) {
		if (args.length < 2) {
			System.out
					.println("Usage ExportDesignLight [OutputPath] [PathToDatabase] optional [server]");
			System.exit(1);
		}

		String basePath = args[0];
		String nsfToExport = args[1];
		String server;
		if (args.length > 2) {
			server = args[2];
		} else {
			server = "";
		}
		// Create a class, start the process
		ExportDesignLite ex = new ExportDesignLite();
		ex.setBasePath(basePath);
		ex.setServer(server);
		ex.setNsfToExport(nsfToExport);

		// What wait delay is needed. Eventually this needs to be much longer
		// for server based databases
		ex.setCrashPreventSleepTime(88);
		// Start processing
		ex.start();

	}

	/**
	 * 
	 * Function to add XML documents to the main XML document from a list of XML
	 * string The result is retuned into a Stream for serialization
	 * 
	 * @param mainXMLString
	 *            String : the base XML string that we add all others to
	 * @param out
	 *            OutputStream : the Stream for the result to return
	 * @param additionalXMLdocStrings
	 *            List of Strings: XMl documents as string from a DXLExporter
	 */
	private boolean addElementsFromList(String mainXMLString, OutputStream out,
			List<String> additionalXMLdocStrings) {
		boolean result = true;
		org.w3c.dom.Document doc = this.domFromString(mainXMLString);
		int i = 0;
		Iterator<String> iter = additionalXMLdocStrings.iterator();
		System.out.println("\n<!-- Start assembly of XML output -->");
		while (iter.hasNext()) {
			System.out.print(".");
			i++;
			if ((i % 100) == 0) {
				System.out.print(" ");
				System.out.println(i);
			}
			String raw = iter.next();
			// org.w3c.dom.Document rawDoc = this.domFromString(raw);
			if (!this.appendExportResult(doc, raw)) {
				result = false;
			}
		}

		// Now render them out
		StreamResult xResult = null;
		DOMSource source = null;

		try {
			TransformerFactory tFactory = TransformerFactory.newInstance();
			Transformer transformer = tFactory.newTransformer();
			xResult = new StreamResult(out);
			source = new DOMSource(doc);
			transformer.transform(source, xResult);

		} catch (Exception e) {
			e.printStackTrace();
			result = false;
		}

		if (result) {
			System.out.println("\n<!-- Assembly of XML output completed -->");
		} else {
			System.out.println("\n<!-- Assembly of XML output failed -->");
		}
		return result;
	}

	/**
	 * adds
	 * 
	 * @param targetXML
	 *            : Existing document, we append the new stuff there
	 * @param newXMLString
	 *            : XML document in string format, we only need the last child
	 */
	private boolean appendExportResult(org.w3c.dom.Document targetXML,
			String appendXMLString) {
		boolean result = false; // we presume failure
		// Parse the string into a DOM document
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		org.w3c.dom.Document sourceDoc;
		try {
			sourceDoc = factory.newDocumentBuilder().parse(
					new InputSource(new StringReader(appendXMLString)));
			// Import the nodes of the new document into doc so that they
			// will be compatible with doc
			Node node = targetXML.importNode(sourceDoc.getDocumentElement(),
					true);

			// We remove from the node the databaseinfo and launchsettings
			// elements since we have them already
			Node curChild = node.getFirstChild();
			while (curChild != null) {
				// We pre-fetch the next sibling in case we remove the curChild
				Node nextSibling = curChild.getNextSibling();
				if (curChild.getNodeType() == Node.ELEMENT_NODE) {
					// We need to check now
					String eName = curChild.getNodeName();
					if (eName.equals("databaseinfo")
							|| eName.equals("launchsettings")) {
						node.removeChild(curChild);
					}
				} else if (curChild.getNodeType() == Node.TEXT_NODE) {
					// This are empty lines on that level we also do not need
					node.removeChild(curChild);

				}

				// Now we set curChild to the prefetched next element
				curChild = nextSibling;
			}

			// Create the document fragment node to hold the new nodes
			DocumentFragment docfrag = targetXML.createDocumentFragment();

			// Move the nodes into the fragment
			while (node.hasChildNodes()) {
				docfrag.appendChild(node.removeChild(node.getFirstChild()));
			}

			// Now append the fragment to the main doc
			targetXML.getDocumentElement().appendChild(docfrag);

			// Once we get here everything worked out
			result = true;

		} catch (SAXException e) {
			e.printStackTrace();
			result = false;
		} catch (IOException e) {
			e.printStackTrace();
			result = false;
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
			result = false;
		}

		return result;

	}

	/**
	 * Creates a DOM object based on a String in XML format. Returns null on
	 * failure
	 * 
	 * @param sourceString
	 *            Something in XML format
	 * @return a proper DOM
	 */
	private org.w3c.dom.Document domFromString(String sourceString) {
		// Create a DOM builder and parse the source
		org.w3c.dom.Document d = null;

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setValidating(false);
		factory.setNamespaceAware(true);

		InputSource source = new InputSource(new StringReader(sourceString));

		try {
			DocumentBuilder docb = factory.newDocumentBuilder();
			d = docb.parse(source);

		} catch (Exception e) {
			e.printStackTrace();
			d = null;
		}

		if (d == null) {
			System.out.println("DOM generation failed:\n" + sourceString);
		}
		return d;
	}

	/**
	 * Executes an export base on a Document collection This class uses it with
	 * a single document
	 * 
	 * @param s
	 *            NotesSession
	 * @param nc
	 *            NotesNoteCollection holding all elements
	 * @param xmlString
	 *            String that will hold the new XML
	 * @return true = it worked
	 */
	private String doTheExport(Session s, DocumentCollection nc) {
		boolean result = false;
		String xmlString = null;
		DxlExporter exporter = null;
		// Export note collection as DXL
		try {
			exporter = s.createDxlExporter();
			exporter.setExitOnFirstFatalError(false); // continue even if we
			// might have a problem
			exporter.setOmitMiscFileObjects(true);
			exporter.setForceNoteFormat(false);
			exporter.setOutputDOCTYPE(false); // We omit the DocType to make
			// sure XSLT doesn't complain

			xmlString = exporter.exportDxl(nc);
			result = true; // Once we get here it worked

		} catch (Exception e) {
			System.out.println("doTheExport Error: " + e.getMessage());
			xmlString = "";
			result = false;
		} finally {
			try {
				if (exporter != null) {
					exporter.recycle();
				}
			} catch (NotesException e2) {
				e2.printStackTrace();
				result = false;
			}
		}

		if (!result) {
			System.out.println("\nExporter failed for one element");
		}
		return xmlString;
	}

	/**
	 * @param nsfToExport
	 *            Filename of the NSF
	 * @param server
	 *            can be empty but not null
	 * @return Did the export work
	 */
	private boolean exportByName(String nsfToExport, String server) {

		Database db = null;
		boolean result = false; // pessimistic!

		try {

			db = this.s.getDatabase(server, nsfToExport);

			// Open DXL file named after current database
			String filename = this.getBasePath() + db.getFilePath() + ".dxl";
			result = this.exportNsfToDxlFile(this.s, db, filename);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				db.recycle();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	/**
	 * @param s
	 *            NotesSession
	 * @param db
	 *            the database to export
	 * @param filename
	 *            the output file name
	 * @return Did it work
	 */
	private boolean exportNsfToDxlFile(Session s, Database db, String filename) {
		NoteCollection nc = null;
		boolean result = false;
		String mainXMLString = null;
		List<String> additionalXMLStrings = new ArrayList<String>();

		try {
			// Open the database
			if (!db.isOpen()) {
				if (!db.open()) {
					System.out.println("Could not open: " + db.getFilePath());
					return result;
				}
			}

			System.out.println("Working on " + db.getFilePath());
			// Create note collection
			nc = db.createNoteCollection(false);
			nc.selectAllNotes(true); // We select everything
			nc.selectAllDataNotes(false); // And de-select the data

			nc.buildCollection();
			// Here is the difference to the full forced export:
			// We do one by one!

			mainXMLString = this.extractDxlFromNodeCollection(db, nc,
					additionalXMLStrings);
			if (mainXMLString.trim().equals("")) {
				result = false;
			} else {

				// Remove file if exists
				File outFile = new File(filename);
				if (outFile.exists()) {
					outFile.delete();
				}

				// Make sure the directory tree exists
				String sep = File.separator;
				int max = filename.lastIndexOf(sep);
				String dirName = filename.substring(0, max);
				File outDir = new File(dirName);
				outDir.mkdirs();

				OutputStream out = new FileOutputStream(outFile);

				// Insert the elements from the array
				this.addElementsFromList(mainXMLString, out,
						additionalXMLStrings);
				out.close();

				result = true; // If we got here it worked

			}

		} catch (Exception e) {
			e.printStackTrace();
			result = false;
		} finally {
			try {
				if (nc != null) {
					nc.recycle();
				}

			} catch (Exception e) {
				System.out.println("ProcessDB Error: " + e.getMessage());
			}
		}

		if (result) {
			System.out.println("Done exporting Design for " + filename);
		} else {
			System.out.println("Failed exporting Design for " + filename);
		}

		return result;
	}

	/**
	 * Walks through a note collection and extracts all the DXL per element
	 * 
	 * @param db
	 *            the database
	 * @param nc
	 *            the collection
	 * @param additionalXMLStrings
	 *            List with XML Strings
	 * @return the root string
	 */
	@SuppressWarnings("static-access")
	private String extractDxlFromNodeCollection(Database db, NoteCollection nc,
			List<String> additionalXMLStrings) {
		String resultXML = null;
		boolean result = true; // We presume everything is fine and toogle to
		// false on error
		String curNodeId = null;

		int count = 1;

		try {
			System.out.println("\n<!-- Starting extraction of DXL -->");
			System.out.print("Collection members: ");
			System.out.print(nc.getCount());
			System.out.println();
			curNodeId = nc.getFirstNoteID();
		} catch (NotesException e1) {
			e1.printStackTrace();
			curNodeId = null;
			result = false;
		}

		boolean firstElement = true; // For the first element we keep the
		// database definition

		while (curNodeId != null && curNodeId.length() > 1) {
			// Export one by one
			Document doc = null;
			try {
				doc = db.getDocumentByID(curNodeId);
			} catch (Exception e) {
				System.out.println("No document for id:" + curNodeId);
				doc = null;
				result = false;
			}
			if (doc != null) {
				DocumentCollection workCollection;
				try {
					workCollection = db.createDocumentCollection();
					workCollection.addDocument(doc);
					// String curNodeMsg = Integer.toString(count) + ". Node: "
					// + curNodeId;
					count++;
					// System.out.println(curNodeMsg);
					System.out.print(".");
					if ((count % 100) == 0) {
						System.out.print(" ");
						System.out.println(count);
					}
					if (firstElement) {
						// We keep the whole result.
						resultXML = this.doTheExport(s, workCollection);
						firstElement = false;
					} else {
						// We extract the inner element and append it
						String someResult = this.doTheExport(s, workCollection);
						additionalXMLStrings.add(someResult);

					}
					// Now we need to sleep a little to give the JNI time for
					// recovery
					this.sleep(this.crashPreventSleepTime);

				} catch (NotesException e) {

					e.printStackTrace();
					result = false;
				} catch (InterruptedException e) {
					e.printStackTrace();
					result = false;
				}

			}
			try {
				curNodeId = nc.getNextNoteID(curNodeId);

			} catch (Exception e) {
				String curNodeMsg = "Error in node " + curNodeId + ": "
						+ e.getMessage();
				System.out.println(curNodeMsg);
				curNodeId = null;
				result = false;
			}

		}

		if (result) {
			System.out.println("\n<!-- Extraction of DXL completed -->");
		} else {
			System.out.println("\n<!-- Extraction of DXL failed -->");
		}

		return resultXML;

	}

	public long getCrashPreventSleepTime() {
		return crashPreventSleepTime;
	}

	public void setCrashPreventSleepTime(long crashPreventSleepTime) {
		this.crashPreventSleepTime = crashPreventSleepTime;
	}

	/**
	 * @return the basePath
	 */
	public String getBasePath() {
		return this.basePath;
	}

	/**
	 * @return the ead
	 */
	public ExportAllDesigns getEad() {
		return this.ead;
	}

	/**
	 * @return the nsfToExport
	 */
	public String getNsfToExport() {
		return this.nsfToExport;
	}

	/**
	 * @return the server
	 */
	public String getServer() {
		return this.server;
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see lotus.domino.NotesThread#runNotes()
	 */
	public void runNotes() {

		// Create a session and database
		try {
			this.s = NotesFactory.createSession();

			this.databasesWorkedOn.put(this.getNsfToExport(), true);
			this.exportByName(this.getServer(), this.getNsfToExport());

			// We the Export Design thread has been started form
			// ExportAllDesigns,
			// We pick the next database and continue the run
			if (this.ead != null) {
				String nextNSF;
				while ((nextNSF = this.ead.getNextDatabase()) != null) {
					this.setNsfToExport(nextNSF);
					if (this.databasesWorkedOn.containsKey(nextNSF)) {
						// We had this already and are probably in a loop,
						// so we abort
						break;
					}
					this.exportByName(this.getServer(), this.getNsfToExport());
				}
			}
		} catch (NotesException e) {
			e.printStackTrace();
		} finally {
			try {
				this.s.recycle();
			} catch (NotesException e) {
				// We don't care
			}
		}
	}

	/**
	 * @param basePath
	 *            the basePath to set
	 */
	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}

	/**
	 * @param ead
	 *            the Export-All-Designs object (used when called by exportAll
	 *            to set database)
	 */
	public void setEad(ExportAllDesigns ead) {
		this.ead = ead;
	}

	/**
	 * @param nsfToExport
	 *            the nsfToExport to set
	 */
	public void setNsfToExport(String nsfToExport) {
		this.nsfToExport = nsfToExport;
	}

	/**
	 * @param server
	 *            the server to set
	 */
	public void setServer(String server) {
		this.server = server;
	}

}
