import java.io.File;
import java.util.TreeMap;

/**
 *  Runs recursively through a directory and analyzes all DXL files it find there
 */

/**
 * @author stw
 * 
 */
public class InspectAllDesigns {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		if (args.length < 2) {
			System.out
					.println("Usage InspectAllDesigns [SourceDir including the trailing shlash] ReportFileName");
			System.exit(1);
		}

		String sourceDir = args[0];

		InspectAllDesigns iad = new InspectAllDesigns(sourceDir);
		iad.process();
		String reportFileName = args[1];
		iad.setReportFileName(reportFileName);
		iad.createReport();

		System.out.println(iad.toString());
	}

	private String reportFileName = null;

	private String sourceDir = null;

	private CaptureMetrics allMetrics = new CaptureMetrics();

	/**
	 * @param SourceDir
	 */
	public InspectAllDesigns(String SourceDir) {
		this.sourceDir = SourceDir;
	}

	/**
	 * @param id
	 *            Inspect Design Object
	 */
	private void captureMetrics(InspectDesign id) {
		try {
			TreeMap<String, Long> allTags = id.getTagNames();
			this.allMetrics.addMetrics(id.getFileName(), allTags);

		} catch (Exception e) {
			System.out.println("captureMetrics error:" + e.getMessage());
		}

	}

	/**
	 * 
	 */
	public void createReport() {

		if (this.getReportFileName() == null) {
			System.out.println("No report file specified, no report created");
			return;
		}
		this.allMetrics.setReportFileName(this.getReportFileName());
		this.allMetrics.createReport();
	}

	/**
	 * @return the reportFileName
	 */
	public String getReportFileName() {
		return this.reportFileName;
	}

	/**
	 * @return Did it work
	 */
	public boolean process() {
		boolean result = false; // pesimistic

		this.processFiles(this.sourceDir);

		result = true; // If we got here it worked

		return result;
	}

	/**
	 * @param string
	 */
	private boolean processFiles(String curFileName) {

		boolean result = false; // pesimistic

		File curFile = new File(curFileName);

		if (curFile.isDirectory()) {
			String[] files = curFile.list();
			String absolutePath = curFile.getAbsolutePath();
			System.out.println("Processing directory " + absolutePath);
			for (int i = 0; i < files.length; i++) {
				String nextPath = absolutePath + File.separator + files[i];
				this.processFiles(nextPath);
			}
		} else {
			// We have a look at the file
			if (curFileName.toLowerCase().endsWith(".dxl")) {
				// That is what we want to analyze
				try {
					InspectDesign inspect = new InspectDesign(curFileName);
					if (inspect.process()) {
						inspect.saveMetrics(curFileName + ".metrics");
					}
					String inspectResult = inspect.toString();
					this.allMetrics.addLog(inspectResult);
					System.out.println(inspectResult);
					System.out.println(); // Empty line

					// Now save it to our global counter
					this.captureMetrics(inspect);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		result = true; // If we got here it worked

		return result;
	}

	/**
	 * @param reportFileName
	 */
	public void setReportFileName(String reportFileName) {
		this.reportFileName = reportFileName;

	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return this.allMetrics.toString();
	}
}
