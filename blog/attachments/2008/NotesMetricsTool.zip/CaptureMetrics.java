import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.util.TreeMap;

/**
 * 
 */

/**
 * Compiles metrics from multiple .metrics files that have been generated for
 * InspectDesign or InspectAllDesigns
 * @author stw
 *
 */
public class CaptureMetrics {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		if (args.length < 2) {
			System.out
					.println("Usage CaptureMetrics [SourceDir including the trailing shlash] ReportFileName");
			System.exit(1);
		}

		String sourceDir = args[0];
		String reportFileName = args[1];

		CaptureMetrics ca = new CaptureMetrics();
		ca.setReportFileName(reportFileName);
		ca.setSourceDir(sourceDir);
		ca.process();
		ca.createReport();

		System.out.println(ca.toString());


	}
	
	private StringBuffer logString = new StringBuffer();
	
	/**
	 * The list of tag items we are interested in
	 */
	TreeMap<String, Integer> listOfTagsForReport = new TreeMap<String, Integer>();

	// Next number for listOfTagsForReport
	int nextTagNumber = 0;

	
	int numberOfDatabases = 0;
	
	private String reportFileName = null;
	
	private String sourceDir = null;
	
	private TreeMap<String, TreeMap<String, Long>> allMetrics = new TreeMap<String, TreeMap<String, Long>>();

	/**
	 * Map to count all the different tags
	 */
	private TreeMap<String, Long> tagCount;
	
	/**
	 * 
	 */
	public CaptureMetrics() {
		int tagCountForReport = 0;
		String propFileName = this.getClass().getName()+".properties";
		File iadProperties = new File(propFileName);
		if (iadProperties.exists()) {
			// We read the list of properties we want in the report from file
			System.out.print("Loading report fields from: "+propFileName);
			BufferedReader in;
			try {
				in = new BufferedReader(new FileReader(iadProperties));
				String line = null;
				while ((line = in.readLine()) != null) {
					this.addTagForReport(line.trim());
					tagCountForReport += 1;
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		if (tagCountForReport == 0) {
			System.out.print("No properties in : "+propFileName+" (or file doesn't exist), loading defaults");
			// Prepopulate list of Tags
			this.addTagForReport("form");
			this.addTagForReport("field");
			this.addTagForReport("view");
			this.addTagForReport("column");
			this.addTagForReport("agent");
			this.addTagForReport("action");
			this.addTagForReport("button");
			this.addTagForReport("subform");
			this.addTagForReport("lotusscript");
			this.addTagForReport("formula");
			this.addTagForReport("javascript");
			this.addTagForReport("java");
			this.addTagForReport("LOC_lotusscript");
			this.addTagForReport("LOC_formula");
			this.addTagForReport("LOC_javascript");
			this.addTagForReport("LOC_java");
			this.addTagForReport("DB_formula");
			this.addTagForReport("UI_formula");
			this.addTagForReport("UI_script");
			this.addTagForReport("UI_event");
		}

	}
	
	/**
	 * @param curName
	 *            Name of the Tag
	 * @param addCount
	 *            how much to add (1 for tags, more for LOC
	 */
	private void addElementCount(String curName, long addCount) {
		Long newValue;
		if (this.tagCount == null) {
			this.tagCount = new TreeMap<String, Long>();
		}
		if (this.tagCount.containsKey(curName)) {
			Long curVal = this.tagCount.get(curName);
			newValue = new Long(curVal.longValue() + addCount);
		} else {
			newValue = new Long(addCount);
		}
		this.tagCount.put(curName, newValue);

	}
	
	/**
	 * @param newLog
	 */
	public void addLog(String newLog) {
		this.logString.append(newLog);
	}

	/**
	 * @param fileName
	 * @param tags
	 */
	public void addMetrics(String fileName, TreeMap<String, Long> tags) {
		this.allMetrics.put(fileName, tags);
		Iterator<String> it = tags.keySet().iterator();

		while (it.hasNext()) {
			String curKey = it.next();
			Long curValue = tags.get(curKey);
			this.addElementCount(curKey, curValue);
		}
		this.numberOfDatabases += 1;

		
	}
	
	/**
	 * @param tagName
	 */
	public void addTagForReport(String tagName) {
		if (!this.listOfTagsForReport.containsKey(tagName)) {
			this.listOfTagsForReport.put(tagName, this.nextTagNumber);
			this.nextTagNumber += 1;
		}

	}


	/**
	 * 
	 */
	public void createReport() {
		if (this.getReportFileName() == null) {
			System.out.println("No report file specified, no report created");
			return;
		}
		// Now we can get started
		File report = new File(this.getReportFileName());
		File logFile = new File(this.getReportFileName() + ".log");

		// We start a fresh report
		if (report.exists()) {
			report.delete();
		}

		if (logFile.exists()) {
			logFile.delete();
		}

		BufferedWriter out = null;
		BufferedWriter logOut = null;

		try {
			// Open the output file
			out = new BufferedWriter(new FileWriter(report));
			logOut = new BufferedWriter(new FileWriter(logFile));

			Iterator<String> iter = this.listOfTagsForReport.keySet()
					.iterator();

			// Write out the first column
			out.append("database");
			while (iter.hasNext()) {
				String fieldName = iter.next();
				out.append(",");
				out.append(fieldName);
			}
			
			out.append("\n");

			// Now write one row per database
			Iterator<String> metricIter = this.allMetrics.keySet().iterator();

			while (metricIter.hasNext()) {
				String metricKey = metricIter.next();
				TreeMap<String, Long> curMetric = this.allMetrics
						.get(metricKey);

				Iterator<String> fieldIter = this.listOfTagsForReport.keySet()
						.iterator();
				out.append(metricKey);

				while (fieldIter.hasNext()) {
					String curField = fieldIter.next();
					out.append(",");
					if (curMetric.containsKey(curField)) {
						out.append(curMetric.get(curField).toString());
					} else {
						out.append("0");
					}
				}
				// Database completed, next line
				out.append("\n");

			}

			logOut.append(this.logString.toString());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				out.close();
				logOut.close();
			} catch (IOException e) {
				// No action taken
			}
		}

	}

	/**
	 * @return the reportFileName
	 */
	public String getReportFileName() {
		return this.reportFileName;
	}

	/**
	 * @return the sourceDir
	 */
	public String getSourceDir() {
		return this.sourceDir;
	}


	/**
	 * @return Did it work
	 */
	public boolean process() {
		boolean result = false; // pesimistic

		this.processFiles(this.sourceDir);

		result = true; // If we got here it worked

		return result;
	}
	
	/**
	 * @param string
	 */
	private boolean processFiles(String curFileName) {

		boolean result = false; // pesimistic

		File curFile = new File(curFileName);

		if (curFile.isDirectory()) {
			String[] files = curFile.list();
			String absolutePath = curFile.getAbsolutePath();
			System.out.println("Processing directory " + absolutePath);
			for (int i = 0; i < files.length; i++) {
				String nextPath = absolutePath + File.separator + files[i];
				this.processFiles(nextPath);
			}
		} else {
			// We have a look at the file
			if (curFileName.toLowerCase().endsWith(".metrics")) {
				// That is what we want to analyze
				try {
					// We load the properties from file and shovel them into the treemap
					Properties prop = new Properties();
					prop.load(new FileInputStream(curFile));
					TreeMap<String, Long> curMap = new TreeMap<String,Long>();
					Iterator<Object> iter = prop.keySet().iterator();
					
					while (iter.hasNext()) {
						String curKey = (String) iter.next();
						Long curVal = new Long(prop.getProperty(curKey));
						curMap.put(curKey, curVal);
					}
					
					this.addMetrics(curFile.getAbsolutePath(), curMap);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		result = true; // If we got here it worked

		return result;
	}


	/**
	 * @param reportFileName the reportFileName to set
	 */
	public void setReportFileName(String reportFileName) {
		this.reportFileName = reportFileName;
	}
	
	/**
	 * @param sourceDir the sourceDir to set
	 */
	public void setSourceDir(String sourceDir) {
		this.sourceDir = sourceDir;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		long total = 0;

		StringBuffer out = new StringBuffer();
		out
				.append("******************************** Results *****************************\n");
		out.append("\n");
		out.append("Databases: ");
		out.append(this.numberOfDatabases);
		out.append("\n");
		Iterator<String> iter = this.tagCount.keySet().iterator();
		while (iter.hasNext()) {
			String curKey = iter.next();
			out.append(curKey);
			out.append(" : ");
			long curResult = this.tagCount.get(curKey).longValue();
			total += curResult;
			out.append(curResult);
			out.append("\n");
		}
		out.append("Total : ");
		out.append(total);
		out.append("\n");
		out
				.append("****************************** Results End ***************************\n");
		out.append("\n\f");
		return out.toString();

	}

	
}
