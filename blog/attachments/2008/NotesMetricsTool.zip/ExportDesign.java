import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.HashMap;

import lotus.domino.Database;
import lotus.domino.DxlExporter;
import lotus.domino.NoteCollection;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

/**
 * Exports the design from a given database
 * 
 * @author stw
 * 
 */
public class ExportDesign extends NotesThread {

	/**
	 * @param args
	 *            Name of the database
	 */
	public static void main(String[] args) {
		if (args.length < 2) {
			System.out
					.println("Usage ExportDesign [OutputPath] [PathToDatabase] optional [server]");
			System.exit(1);
		}

		String basePath = args[0];
		String nsfToExport = args[1];
		String server;
		if (args.length > 2) {
			server = args[2];
		} else {
			server = "";
		}
		// Create a class, start the process
		ExportDesign ex = new ExportDesign();
		ex.setBasePath(basePath);
		ex.setServer(server);
		ex.setNsfToExport(nsfToExport);
		// Start processing
		ex.start();

	}

	// Directory for exporting to
	private String basePath;

	// Name of the NSF
	private String nsfToExport;

	// Name of the server, default is local (empty)
	private String server = "";

	// Master object if there is any
	private ExportAllDesigns ead = null;

	// The Notessession
	private Session s = null;

	// List of databases we worked on. To avoid a loop
	private HashMap<String, Boolean> databasesWorkedOn = new HashMap<String, Boolean>();

	private String doTheExport(Session s, NoteCollection nc) {
		String result = null;
		DxlExporter exporter = null;
		// Export note collection as DXL
		try {
			exporter = s.createDxlExporter();
			exporter.setExitOnFirstFatalError(false); // continue even if we
			// might have a problem
			exporter.setOmitMiscFileObjects(true);
			exporter.setForceNoteFormat(false);
			exporter.setOutputDOCTYPE(false); // We omit the DocType to make
			// sure XSLT doesn't complain

			result = exporter.exportDxl(nc);

		} catch (Exception e) {
			System.out.println("doTheExport Error: " + e.getMessage());
			result = "";
		} finally {
			try {
				if (exporter != null) {
					exporter.recycle();
				}
			} catch (NotesException e2) {
				// We don't look at that one
			}
		}

		return result;
	}

	/**
	 * @return the basePath
	 */
	public String getBasePath() {
		return this.basePath;
	}

	/**
	 * @return the ead
	 */
	public ExportAllDesigns getEad() {
		return this.ead;
	}

	/**
	 * @return the nsfToExport
	 */
	public String getNsfToExport() {
		return this.nsfToExport;
	}

	/**
	 * @return the server
	 */
	public String getServer() {
		return this.server;
	}

	/**
	 * @param nsfToExport
	 *            Filename of the NSF
	 * @param server
	 *            can be empty but not null
	 * @return Did the export work
	 */
	private boolean process(String nsfToExport, String server) {

		Database db = null;
		boolean result = false; // pessimistic!

		try {

			db = this.s.getDatabase(server, nsfToExport);

			// Open DXL file named after current database
			String filename = this.getBasePath() + db.getFilePath() + ".dxl";
			result = this.processDB(this.s, db, filename);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				db.recycle();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	/**
	 * @param s
	 *            NotesSession
	 * @param db
	 * @param filename
	 * @return Did it work
	 */
	private boolean processDB(Session s, Database db, String filename) {
		NoteCollection nc = null;
		boolean result = false;

		try {
			// Open the database
			if (!db.isOpen()) {
				if (!db.open()) {
					System.out.println("Could not open: " + db.getFilePath());
					return false;
				}
			}

			System.out.println("Working on "+db.getFilePath());
			// Create note collection
			nc = db.createNoteCollection(false);
			nc.selectAllNotes(true); // We select everything
			nc.selectAllDataNotes(false); // And de-select the data
			
			nc.buildCollection();

			String output = this.doTheExport(s, nc);

			if (output.trim().equals("")) {
				result = false;
			} else {

				// Remove file if exists
				File outFile = new File(filename);
				if (outFile.exists()) {
					outFile.delete();
				}

				// Make sure the direcotry tree exists
				String sep = File.separator;
				int max = filename.lastIndexOf(sep);
				String dirName = filename.substring(0, max);
				File outDir = new File(dirName);
				outDir.mkdirs();

				Writer out = new OutputStreamWriter(new FileOutputStream(
						outFile), "UTF-8");

				out.write(output);
				out.close();
			}
			result = true; // If we got here it worked
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (nc != null) {
					nc.recycle();
				}

			} catch (Exception e) {
				System.out.println("ProcessDB Error: " + e.getMessage());
			}
		}
		if (result) {
			System.out.println("Done exporting Design for " + filename);
		} else {
			System.out.println("Failed exporting Design for " + filename);
		}

		return result;
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see lotus.domino.NotesThread#runNotes()
	 */
	public void runNotes() {

		// Create a session and database
		try {
			this.s = NotesFactory.createSession();

			this.databasesWorkedOn.put(this.getNsfToExport(), true);
			this.process(this.getServer(), this.getNsfToExport());

			// We the Export Design thread has been started form
			// ExportAllDesigns,
			// We pick the next database and continue the run
			if (this.ead != null) {
				String nextNSF;
				while ((nextNSF = this.ead.getNextDatabase()) != null) {
					this.setNsfToExport(nextNSF);
					if (this.databasesWorkedOn.containsKey(nextNSF)) {
						// We had this already and are probably in a loop,
						// so we abort
						break;
					}
					this.process(this.getServer(), this.getNsfToExport());
				}
			}
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				this.s.recycle();
			} catch (NotesException e) {
				// We don't care
			}
		}
	}

	/**
	 * @param basePath
	 *            the basePath to set
	 */
	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}

	/**
	 * @param ead
	 *            the ead to set
	 */
	public void setEad(ExportAllDesigns ead) {
		this.ead = ead;
	}

	/**
	 * @param nsfToExport
	 *            the nsfToExport to set
	 */
	public void setNsfToExport(String nsfToExport) {
		this.nsfToExport = nsfToExport;
	}

	/**
	 * @param server
	 *            the server to set
	 */
	public void setServer(String server) {
		this.server = server;
	}

}
