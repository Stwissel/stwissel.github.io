package tools;

import java.io.File;

import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.Element;

public class BuddyListCombiner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		if (args.length < 2) {
			System.out
					.println("Please provide 3 parameters: combine|report DirectoryName ReportXSLTName");
			return;
		}

		BuddyListCombiner blc = new BuddyListCombiner();

		// Only if combine then we need
		if (args[0].compareToIgnoreCase("combine") == 0) {
			blc.combine(args[1]);
		}

		blc.report(args[1], args[2]);

	}

	private DomHelper dh = DomHelper.getDomHelper();

	private static final String FILE_NAME = "ReportOnBuddies.xml";

	public void report(String xmlDir, String xsltFile) {
		Document raw = dh.file2Dom(xmlDir+FILE_NAME);
		Document style = dh.file2Dom(xsltFile);
		
		String result = dh.domTransForm(raw, style);
		
		dh.string2File(xmlDir+"report.html", result);

	}

	public void combine(String xmlDir) {

		File dir = new File(xmlDir);

		if (!dir.isDirectory()) {
			System.out.println(xmlDir + " is not a directory, can proceed");
			return;
		}

		// Get a XMLRoot document

		Document result = dh.string2Dom("<buddylists />");
		Element root = (Element) result.getChildNodes().item(0);

		String[] allFiles = dir.list();

		for (String curFile : allFiles) {
			if (curFile.startsWith("BuddyList")) {
				this.appendBuddyFile(result, root, xmlDir + curFile);
			}
		}
		
		dh.dom2File(result, xmlDir+FILE_NAME);

	}

	private void appendBuddyFile(Document doc, Element root,
			String buddyfilename) {

		try {

			Document onelist = dh.file2Dom(buddyfilename);
			//Insert the sequence number
			String sequence = buddyfilename.substring(buddyfilename.lastIndexOf("BuddyList")+9, buddyfilename.indexOf(".xml"));
			Element topElement = (Element) onelist.getDocumentElement(); 
			topElement.setAttribute("userid", sequence);
			
			String oneString = dh.dom2String(onelist); // This gets rid of the XML declaration
			
			DocumentFragment frag = dh.string2DocumentFragment(doc, oneString);
			root.appendChild(frag);

		} catch (Exception e) {
			System.out.println(buddyfilename + " didn't work");
		}

	}

}
